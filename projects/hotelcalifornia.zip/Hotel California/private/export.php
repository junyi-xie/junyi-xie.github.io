<?php
require 'class.php';

$db->printinvoice();
?>